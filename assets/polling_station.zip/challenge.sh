#!/usr/bin/bash
cd /ctf
./polling_station
