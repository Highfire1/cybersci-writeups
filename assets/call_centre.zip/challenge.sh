#!/usr/bin/bash
cd /ctf
./call_centre
