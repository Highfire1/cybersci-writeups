﻿using Microsoft.AspNetCore.Authentication;

namespace SecretRally.Auth
{
    public class JwtAuthOptions : AuthenticationSchemeOptions
    {
    }
}
